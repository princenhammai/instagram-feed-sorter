import{J as p}from"./sync-BuQ9A9Pl.js";function f(e,t){const s=e??Number.NEGATIVE_INFINITY;return(t??Number.NEGATIVE_INFINITY)-s}function m(e,t){switch(t){case"views":return e.views;case"comments":return e.comments;case"outlier":return e.outlierScore;case"engagement":return e.engagementRate;case"duration":return e.duration;case"median":return e.medianScore;case"likeRate":return e.likeRate;case"commentRate":return e.commentRate;default:return e.likes}}function y(e,t){const s=[...e];return s.sort((n,o)=>t==="oldest"?n.takenAt-o.takenAt||n.id.localeCompare(o.id):t==="newest"?o.takenAt-n.takenAt||o.id.localeCompare(n.id):f(m(n,t),m(o,t))||o.takenAt-n.takenAt),s}function k(e,t){const s=t.toLowerCase().split(/\s+/).filter(Boolean);return s.length===0?e:e.filter(n=>{const o=`${n.caption} ${n.username} ${n.shortcode} ${n.audio??""}`.toLowerCase();return s.every(r=>o.includes(r))})}function T(e,t){const s=new Map(e.map(n=>[n.id,n]));return t.flatMap(n=>{const o=s.get(n);return o?[o]:[]})}function u(e){let t=e+1,s="";for(;t>0;){const n=(t-1)%26;s=String.fromCharCode(65+n)+s,t=Math.floor((t-1)/26)}return s}function c(e){return e.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function h(e){const t=e.replace(/[:\\/?*[\]]/g," ").trim()||"Posts";return c(t.slice(0,31))}function d(e){return`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${e.map((s,n)=>{const o=s.map((r,l)=>{if(r==null||r==="")return"";const i=`${u(l)}${n+1}`;return typeof r=="number"&&Number.isFinite(r)?`<c r="${i}"><v>${r}</v></c>`:`<c r="${i}" t="inlineStr"><is><t xml:space="preserve">${c(String(r))}</t></is></c>`}).join("");return`<row r="${n+1}">${o}</row>`}).join("")}</sheetData></worksheet>`}async function x(e){const t=e.length>0?e:[{name:"Sheet1",rows:[]}],s=t.length+1,n=t.map((i,a)=>`  <Override PartName="/xl/worksheets/sheet${a+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join(`
`),o=t.map((i,a)=>`<sheet name="${h(i.name)}" sheetId="${a+1}" r:id="rId${a+1}"/>`).join(""),r=t.map((i,a)=>`  <Relationship Id="rId${a+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${a+1}.xml"/>`).join(`
`),l=new p;return l.file("[Content_Types].xml",`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
${n}
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>`),l.file("_rels/.rels",`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`),l.file("xl/workbook.xml",`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>${o}</sheets>
</workbook>`),l.file("xl/_rels/workbook.xml.rels",`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
${r}
  <Relationship Id="rId${s}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`),l.file("xl/styles.xml",`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
  <fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
  <borders count="1"><border/></borders>
  <cellStyleXfs count="1"><xf/></cellStyleXfs>
  <cellXfs count="1"><xf/></cellXfs>
</styleSheet>`),t.forEach((i,a)=>{l.file(`xl/worksheets/sheet${a+1}.xml`,d(i.rows))}),l.generateAsync({type:"arraybuffer"})}async function w(e,t){return x([{name:e,rows:t}])}export{x as a,w as b,k as c,T as p,y as s};
